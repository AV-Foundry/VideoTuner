from .init import sys, main

main(sys.argv[1:])
